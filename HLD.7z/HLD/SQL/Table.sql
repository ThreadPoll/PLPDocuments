DROP TABLE User_Master CASCADE CONSTRAINTS;

CREATE TABLE User_Master(
user_Id VARCHAR2(10),
user_Name VARCHAR2(20),
user_Password VARCHAR2(20),
user_Type VARCHAR2(20)
);

INSERT INTO User_Master VALUES(1001,'Girjesh'	,'pass@123',	'admin'  );
INSERT INTO User_Master VALUES(1002,'Aman'		,'pass@123',	'admin'  );
INSERT INTO User_Master VALUES(1003,'Khushboo'	,'pass@123',	'admin'  );
INSERT INTO User_Master VALUES(1004,'Divakar'	,'pass@123',	'admin'  );
INSERT INTO User_Master VALUES(1005,'Nidhi'	    ,'pass@123',	'admin'  );
INSERT INTO User_Master VALUES(1006,'Sneha'	    ,'pass@123',	'manager');
INSERT INTO User_Master VALUES(1007,'Chitranjan','pass@123',	'manager');
INSERT INTO User_Master VALUES(1008,'Harshita'	,'pass@123',	'manager');
INSERT INTO User_Master VALUES(1009,'Namita'	,'pass@123',	'manager');
INSERT INTO User_Master VALUES(1010,'Ashok'	    ,'pass@123',	'manager');


DROP TABLE Department CASCADE CONSTRAINTS;

CREATE TABLE Department(
dept_Id INT PRIMARY KEY,
dept_Name VARCHAR2(50)
);

INSERT INTO Department VALUES(10,'Java');
INSERT INTO Department VALUES(20,'Oracle');
INSERT INTO Department VALUES(30,'MainFrame');
INSERT INTO Department VALUES(40,'Business Intellegence');
INSERT INTO Department VALUES(50,'Financial Services');

DROP TABLE Employee CASCADE CONSTRAINTS;

CREATE TABLE Employee(
emp_No NUMBER(6) PRIMARY KEY,
e_Name VARCHAR2(25),
job VARCHAR2(50),
mgr NUMBER(4),
hire_Date DATE,
dept_Id INT,
FOREIGN KEY (dept_Id) REFERENCES Department(dept_Id)
);

INSERT INTO Employee VALUES(1001,'Girjesh'	,	'Admin'   						,	null,'06-NOV-2016',10);
INSERT INTO Employee VALUES(1002,'Aman'		,	'Admin'   						,	null,'17-NOV-1995',30);
INSERT INTO Employee VALUES(1003,'Khushboo'	,	'Admin'   						,	null,'14-AUG-1980',20);
INSERT INTO Employee VALUES(1004,'Divakar'	,	'Admin'   						,	null,'17-JAN-1999',40);
INSERT INTO Employee VALUES(1005,'Nidhi'	,	'Admin'   						,	null,'20-DEC-2000',50);
INSERT INTO Employee VALUES(1006,'Sneha'	,	'MainFrame Manager'   			,	1006,'01-FEB-2002',30);
INSERT INTO Employee VALUES(1007,'Chitranjan',	'Oracle Manager'   				,	1007,'30-NOV-2004',20);
INSERT INTO Employee VALUES(1008,'Harshita'	,	'Financial Services Manager'	,	1008,'08-MAR-2007',50);
INSERT INTO Employee VALUES(1009,'Namita'	,	'Java Manager'   				,	1009,'24-APR-2004',10);
INSERT INTO Employee VALUES(1010,'Ashok'	,	'Business Intelligence Manager'	,	1010,'09-JUN-2010',40);
INSERT INTO Employee VALUES(1011,'Varsha'	,	'Database Engineer'   			,	1007,'10-JUL-2000',50);
INSERT INTO Employee VALUES(1012,'Vishal'	,	'Software Engineer'   			,	1008,'22-SEP-2012',10);
INSERT INTO Employee VALUES(1013,'Samarth'	,	'EnterPrises Engineer' 			,	1010,'27-OCT-1997',20);
INSERT INTO Employee VALUES(1014,'Tanmay'	,	'Database Engineer'   			,	1009,'20-APR-1999',50);
INSERT INTO Employee VALUES(1015,'Rajat'	,	'Financial Engineer'   			,	1006,'14-DEC-2001',40);
INSERT INTO Employee VALUES(1016,'Omkar'	,	'Testing Engineer'   			,	1008,'10-JAN-1997',30);
INSERT INTO Employee VALUES(1017,'Chirag'	,	'Database Engineer'   			,	1007,'31-DEC-2012',10);
INSERT INTO Employee VALUES(1018,'Ibrahim'	,	'Software Engineer'   			,	1010,'01-NOV-2014',30);
INSERT INTO Employee VALUES(1019,'Mohit'	,	'Financial Services Engineer'   ,	1009,'21-MAR-2016',40);
INSERT INTO Employee VALUES(1020,'Umang'	,	'Network Analyst'   			,	1008,'21-MAR-2001',50);
INSERT INTO Employee VALUES(1021,'Akansha'	,	'Database Engineer'   			,	1010,'03-APR-2014',40);
INSERT INTO Employee VALUES(1022,'Rushika'	,	'Software Engineer'   			,	1006,'14-AUG-2000',10);
INSERT INTO Employee VALUES(1023,'Lalak'	,	'Testing Engineer'   			,	1007,'10-JUL-2001',20);
INSERT INTO Employee VALUES(1024,'Nupur'	,	'Financial Services Manager'   	,	1008,'13-SEP-2004',40);
INSERT INTO Employee VALUES(1025,'Tanu'		,	'EnterPrises Engineer'   		,	1006,'23-JUN-2010',30);
INSERT INTO Employee VALUES(1026,'Sapna'	,	'Financial Services Engineer'   ,	1008,'24-AUG-1999',30);
INSERT INTO Employee VALUES(1027,'Vinod'	,	'Database Engineer'   			,	1010,'05-NOV-2015',50);
INSERT INTO Employee VALUES(1028,'Ity'		,	'Network Analyst'   			,	1009,'17-MAR-2000',10);
INSERT INTO Employee VALUES(1029,'Farheen'	,	'Software Engineer'   			,	1006,'28-MAY-2014',20);
INSERT INTO Employee VALUES(1030,'Heena'	,	'EnterPrises Engineer'   		,	1007,'10-OCT-2016',40);
INSERT INTO Employee VALUES(1031,'Urvashi'	,	'Testing Engineer'   			,	1008,'15-APR-2000',20);
INSERT INTO Employee VALUES(1032,'Sakshi'	,	'Financial Services Engineer'  	,	1009,'24-MAR-2003',30);
INSERT INTO Employee VALUES(1033,'Shruti'	,	'Database Engineer'   			,	1010,'20-JAN-2004',50);
INSERT INTO Employee VALUES(1034,'Shikhar'	,	'Network Analyst'   			,	1007,'14-FEB-2007',40);
INSERT INTO Employee VALUES(1035,'Karan'	,	'EnterPrises Engineer'   		,	1009,'20-MAR-2010',10);
INSERT INTO Employee VALUES(1036,'Saurabh'	,	'Software Engineer'   			,	1007,'25-DEC-1999',20);
INSERT INTO Employee VALUES(1037,'Prathu'	,	'Testing Engineer'   			,	1009,'13-MAR-2000',30);
INSERT INTO Employee VALUES(1038,'Yogesh'	,	'Software Engineer'   			,	1007,'13-APR-2002',40);
INSERT INTO Employee VALUES(1039,'John'		,	'Financial Services Engineer'   ,	1006,'29-JUL-2014',50);
INSERT INTO Employee VALUES(1040,'Sam'		,	'Database Engineer'   			,	1008,'12-OCT-1998',30);
INSERT INTO Employee VALUES(1041,'Eric'		,	'EnterPrises Engineer'   		,	1006,'10-MAR-2003',20);
INSERT INTO Employee VALUES(1042,'Tommy'	,	'Database Engineer'   			,	1007,'05-JUL-2005',40);
INSERT INTO Employee VALUES(1043,'Lawrene'	,	'Network Analyst'   			,	1010,'24-AUG-2005',50);
INSERT INTO Employee VALUES(1044,'Nishan'	,	'Software Engineer'   			,	1009,'05-NOV-2005',10);
INSERT INTO Employee VALUES(1045,'Smith'	,	'EnterPrises Engineer'   		,	1010,'14-SEP-2008',30);
INSERT INTO Employee VALUES(1046,'Shawn'	,	'Associate Engineer'   			,	1009,'14-OCT-2004',40);
INSERT INTO Employee VALUES(1047,'James'	,	'Associate Engineer'   			,	1006,'09-NOV-1997',50);
INSERT INTO Employee VALUES(1048,'Kelly'	,	'Network Engineer'   			,	1008,'01-JAN-2000',20);
INSERT INTO Employee VALUES(1049,'Simmy'	,	'Database Engineer'   			,	1007,'04-MAR-2002',40);
INSERT INTO Employee VALUES(1050,'Vatsal'	,	'Financial Services Engineer'   ,	1009,'24-JUL-2008',50);
INSERT INTO Employee VALUES(1051,'Lee'		,	'Testing Engineer'   			,	1007,'21-MAR-2009',20);
INSERT INTO Employee VALUES(1052,'Jimmy'	,	'Associate Engineer'   			,	1007,'10-FEB-2010',40);
INSERT INTO Employee VALUES(1053,'Payal'	,	'Network Engineer'   			,	1008,'27-MAR-2011',10);
INSERT INTO Employee VALUES(1054,'Sia'		,	'Database Engineer'   			,	1010,'13-JUN-2012',20);
INSERT INTO Employee VALUES(1055,'Shayma'	,	'Network Engineer'   			,	1009,'26-NOV-2005',50);
INSERT INTO Employee VALUES(1056,'Sinkon'	,	'Associate Engineer'   			,	1010,'31-OCT-2007',10);
INSERT INTO Employee VALUES(1057,'Yang'		,	'Database Engineer'   			,	1007,'14-NOV-1995',30);
INSERT INTO Employee VALUES(1058,'Krisha'	,	'Financial Services Manager'   	,	1008,'20-JUL-2008',40);
INSERT INTO Employee VALUES(1059,'Prisha'	,	'Associate Engineer'   			,	1009,'17-NOV-2010',50);
INSERT INTO Employee VALUES(1060,'Devansh'	,	'Associate Engineer'   			,	1007,'07-DEC-2012',20);

DROP TABLE Asset CASCADE CONSTRAINTS;

CREATE TABLE Asset(
asset_Id NUMBER PRIMARY KEY,
asset_Name VARCHAR2(25),
asset_Des VARCHAR2(25),
quantity NUMBER,
status VARCHAR2(15)
);

DROP TABLE Asset_Allocation CASCADE CONSTRAINTS;

CREATE TABLE Asset_Allocation(
allocation_Id NUMBER PRIMARY KEY,
asset_Id NUMBER,
emp_No NUMBER,
allocation_Date DATE,
release_Date DATE,
FOREIGN KEY (asset_Id) REFERENCES Asset(asset_Id),
FOREIGN KEY (emp_No) REFERENCES Employee(emp_No)
);


CREATE SEQUENCE generate_allocation_Id START WITH 10000;

CREATE SEQUENCE generate_asset_Id START WITH 100;
COMMIT;

